function result_output(io, alg_name, final_loss, opt_loss, x_est, x_true, time_taken, subprob_iters, outer_iters)
    rel_error = min(norm(x_est - x_true) / norm(x_true), norm(x_est + x_true) / norm(x_true));
    println(io, "#################################################################################")
    println(io, alg_name, " Completed.");
    println(io, alg_name, " Final loss: ", final_loss);
    println(io, alg_name, " Loss Gap: ", final_loss - opt_loss);
    println(io, alg_name, " relative recovery error: ", rel_error);
    println(io, alg_name, " Time consumption: ", time_taken);
    println(io, alg_name, " subproblem iterations: ", subprob_iters);
    println(io, alg_name, " Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x_true)/norm(x_true)^2)*x_true;
    orth_part=x_est-proj_part;
    println(io, alg_name, " projection norm: ", norm(proj_part));
    println(io, alg_name, " orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
end