function ProxLinearQuadratic(A::Matrix{Float64}, b::Vector{Float64};
    x_init::Vector{Float64} = randn(size(A, 2)),
    tol::Float64 = 1e-3,
    maxiter::Int64 = length(b),
    eps_qp::Float64 = 1e-4,
    rel_error_tol::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),
    opnorm_A::Float64 = -1.0)
    ##############
    x_curr = x_init;
    steplength = Inf;
    (nn, dd) = size(A);
    if opnorm_A < 0
        opnorm_A = opnorm(A);
    end
    lipschitz_const = 2 * opnorm_A^2;
    iter = 0;
    total_iters = 0;
    
    objs = [];
    iter_count=0;
    rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
    obj = sum(abs.((A * x_curr).^2 - b));
    objs = cat(objs, obj, dims=1)
    while (iter < maxiter && steplength > tol && rel_error > rel_error_tol)
        dx = zeros(dd);
        # Minimize the loss
        # norm(inner_grad_mat * delta_x - (b - (A * x_curr).^2), 1)
        #  + (lipschitz_const / 2) * ||delta_x||_2^2
        inner_grad_mat =  Diagonal(2/lipschitz_const * (A * x_curr)) * A;
        #qp_solver == :graph
        (dx, iter_count) =
        SolveQP_graph_form(inner_grad_mat, 1/lipschitz_const*(b - (A * x_curr).^2), 
                eps_abs = eps_qp, eps_rel = eps_qp, rho = 4.0);
        total_iters += iter_count;

        grad_map = lipschitz_const/2 * dx;
        x_curr = x_curr + dx[:];
        steplength = norm(grad_map);
        iter = iter + 1;
        obj = sum(abs.((A * x_curr).^2 - b));
        objs = cat(objs, obj, dims=1);#some change happens here
        rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
    end
    return (x_curr, objs, total_iters, iter);
end

# (x, iter) = SolveQP_graph_form(A::Matrix{Float64}, c_vec::Vector{Float64};
#                                x_init::Vector{Float64} = zeros(size(A, 2)),
#                                eps_abs::Float64 = 1e-5,
#                                rho::Float64 = 1.0,
#                                eps_rel::Float64 = 1e-4,
#                                update_rho::Bool = false,
#                                verbose_level::Int64 = 0,
#                                MAXITER::Int64 = 1000,
#                                use_cg::Bool = false)
#
# Applies Parikh and Boyd's graph form proximal splitting to solve quadratic
# problems of the form
#
# min. norm(A * x - c, 1) + (1/2) * norm(x)^2
#
# starting from the given initialization point.
function SolveQP_graph_form(A::Matrix{Float64}, c_vec::Vector{Float64};
   eps_abs::Float64 = 1e-5,
   rho::Float64 = 1.0,
   eps_rel::Float64 = 1e-4,
   MAXITER::Int64 = 1000)
    primal_residual_norm = Inf;
    dual_residual_norm = Inf;
    norm_duals = 0.0;
    norm_primals = 0.0;
    nn = length(c_vec);
    dd = size(A, 2);
    iter = 0;
    x_iter = zeros(dd);
    y_iter = zeros(nn);

    x_half = zeros(dd);
    y_half = zeros(nn);
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    resid_dual = zeros(dd + nn);
    resid_primal = zeros(dd + nn);
    lambda = zeros(dd);
    nu = zeros(nn);
    obj = Inf;
    #IplusAtAinv = inv(eye(dd) + A' * A);
    IplusAtAinv = inv(I + A' * A);#Do some change here
    while (((primal_residual_norm > sqrt(nn + dd) * eps_abs + eps_rel * norm_primals) || (dual_residual_norm > sqrt(nn + dd) * eps_abs + eps_rel * norm_duals)) && iter < MAXITER)
        iter += 1;
        # Store residuals for later use
        resid_dual[1:dd] = x_iter;
        resid_dual[(dd+1):end] = y_iter;
        # Compute update steps
        x_half = (rho / (1 + rho)) * (x_iter - lambda);
        n_work_vec = y_iter - nu - c_vec;
        y_half = c_vec + sign.(n_work_vec) .* max.(abs.(n_work_vec) .- 1/rho, 0);
        #here is a modification that change - to .- for broadcasting
        d_work_vec = x_half + lambda + A' * (y_half + nu);

        x_iter = IplusAtAinv * d_work_vec;
        y_iter = A * x_iter;
        lambda += (x_half - x_iter);
        nu += (y_half - y_iter);

        # Primal residual = [x_{k+1}; y_{k+1}] - [x_{k + 1/2}, y_{k + 1/2}]
        # Dual residual = rho * [x_k - x_{k + 1}; y_k - y_{k + 1}].
        resid_primal[1:dd] = x_half - x_iter;
        resid_primal[(dd+1):end] = y_half - y_iter;
        resid_dual[1:dd] -= x_iter;
        resid_dual[(dd+1):end] -= y_iter;
        primal_residual_norm = norm(resid_primal);
        dual_residual_norm = rho * norm(resid_dual);
        norm_primals = max(sqrt(dot(x_iter, x_iter) + dot(y_iter, y_iter)), sqrt(dot(y_half, y_half) + dot(x_half, x_half)));
        norm_duals = rho * sqrt(dot(lambda, lambda) + dot(nu, nu));
        obj = dot(x_iter, x_iter) / 2 + norm(y_iter - c_vec, 1);
    end
    return (x_iter, iter);
end