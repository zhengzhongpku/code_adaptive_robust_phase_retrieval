function stochastic_algorithms(A::Matrix{Float64}, b::Vector{Float64}, method::String;
    T::Int64 = 100,
    K::Int64 = 100,
    alpha0::Float64 = 0.1,
    x_init::Vector{Float64} = randn(size(A, 2)),
    rel_error_tol::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),
    
    if_verbose::Int64 = 0)
    #############################
    ############################
    if ~((method == "sg")||(method == "pl")||(method == "cl"))
        error("method error")
    end
    (nn, dd) = size(A);
    x_current = zeros(dd);
    a = zeros(dd);
    subgrad = zeros(dd);
    x_current .= x_init;
    seed = 100;
    Random.seed!(seed);
    t = 0;
    iters = 0;
    for t in 0:(T-1)
        alpha = alpha0*(2.0^(-t));
        k0 = rand(0:(K-1));
        iters = iters + k0 - 1
        for k in 0:k0
            ind = rand(1:nn);
            a .= A[ind,:];
            bi = b[ind];
            innprod = dot(a,x_current);
            resid = innprod^2 - bi;
            if method == "sg"
                subgrad .= (2*sign(resid)*innprod) .* a;
                x_current .= x_current .- alpha.* subgrad;
            end
            if method == "pl"
                norm_a = norm(a);
                temp = resid/(4*alpha*innprod^2*norm_a^2);
                if abs(temp)>1
                    temp = sign(temp);
                end
                x_current .= x_current .- (2*temp*alpha*innprod) .* a;
            end
            if method == "cl"
                subgrad .= (2*sign(resid)*innprod) .* a;
                norm_sub = norm(subgrad);
                if norm_sub == 0.0
                    temp = 0.0
                else
                    temp = abs(resid)/(alpha*(norm_sub^2))
                end
                # if isequal(temp, NaN)
                #     println(abs(resid))
                #     println(norm_sub)
                #     println(sum((A*x_current).^2 .== b))
                #     error("NaN")
                # end
                # It is so surprising that norm_sub can be 0.
                if temp > 1.0
                    temp = 1.0
                end
                x_current .= x_current .- (temp*alpha) .* subgrad;
            end
        end
        rel_error = min(norm(x_true - x_current),norm(x_true + x_current))/norm(x_true);
        if if_verbose == 1
            println("t: ", t, ", rel_error: ", rel_error);
        end
        if rel_error<= rel_error_tol
            return (x_current,t,iters)
        end
    end
    return (x_current,t,iters)

end
