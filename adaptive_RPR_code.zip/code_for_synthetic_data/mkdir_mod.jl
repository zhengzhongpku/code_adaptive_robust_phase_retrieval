for failmulti in ["1"]
    for pfail in ["04"]
        for dd in ["0","1"]
            for kk in ["08","12","16","20","24"]
                path="./result/1"*kk*dd*pfail*failmulti*"/"
                if ~isdir(path)
                    mkdir(path);
                end
            end
        end
    end
end
