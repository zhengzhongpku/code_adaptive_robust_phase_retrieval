
function Solving_problem_subgradient(A::Matrix{Float64}, b::Vector{Float64};
    x_init::Vector{Float64} = randn(size(A, 2)),
    loss_tol::Float64 = -1.0,
    lambda::Float64 = -1.0,
    q::Float64 = 0.998,
    maxiter::Int64 = 10000,
    rel_error_tol::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),)
  x_curr = x_init;
  if lambda<0
    lambda=norm(x_init)/10;
  end
  #println("lambda: ", lambda);
  obj = Inf;
  (nn, dd) = size(A);
  iter = 0;
  total_iters = 0;
  objs = [];
  iter_count=0;
  amplit=A * x_curr;
  res=(amplit).^2 - b;
  stepsize=lambda/q;

  rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
  obj = sum(abs.((A * x_curr).^2 - b));
  objs = cat(objs, obj, dims=1)
  while (iter < maxiter && obj > loss_tol  && rel_error > rel_error_tol)
    stepsize=stepsize*q;
    # Minimize the loss
    # norm(inner_grad_mat * delta_x - (b - (A * x_curr).^2), 1)
    #  + (lipschitz_const / 2) * ||delta_x||_2^2
    dx = 2 * (A') * (amplit .* sign.(res));
    dx = dx/norm(dx);
    x_curr = x_curr - stepsize*dx[:];
    iter = iter + 1;
    amplit = A * x_curr;
    res = amplit.^2 - b;
    obj = sum(abs.(res));
    objs = cat(objs, obj, dims=1);#some change happens here
    # if mod(iter,100)==0
    #   println(obj)
    # end
    rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
  end
  total_iters=iter;
  return (x_curr, objs, total_iters);
  end
