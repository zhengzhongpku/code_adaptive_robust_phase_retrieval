
function Solving_problem_subgradient_median(A::Matrix{Float64}, b::Vector{Float64};
    x_init::Vector{Float64} = randn(size(A, 2)),
    loss_tol::Float64 = -1.0,
    g_multiplier::Float64 = 0.5,
    maxiter::Int64 = 10000,
    rel_error_tol::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),)


  #println("lambda: ", lambda);
  obj = Inf;
  (nn, dd) = size(A);
  x_curr = zeros(dd)
  x_curr .= x_init;
  iter = 0;
  total_iters = 0;
  objs = [];
  iter_count=0;
  amplit = zeros(nn);
  amp_res = zeros(nn);
  dx = zeros(dd);
  res = zeros(nn);
  abs_res = zeros(nn);
  mul!(amplit, A, x_curr);#amplit=A * x_curr;
  res .= amplit.^2 .- b;
  abs_res .= abs.(res);

  rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
  obj = mean(abs_res);
  objs = cat(objs, obj, dims=1)
  while (iter < maxiter && obj > loss_tol  && rel_error > rel_error_tol)
    # Minimize the loss
    # norm(inner_grad_mat * delta_x - (b - (A * x_curr).^2), 1)
    #  + (lipschitz_const / 2) * ||delta_x||_2^2
    amp_res .= (2/nn) .* amplit .* sign.(res);
    mul!(dx, A', amp_res); #dx = 2 * (A') * (amplit .* sign.(res));
    med_resid = median(abs_res);
    x_curr .= x_curr .- (med_resid * g_multiplier/(norm(dx)^2)) .* dx;
    iter = iter + 1;
    mul!(amplit, A, x_curr); #amplit = A * x_curr;
    res .= amplit.^2 .- b;#res = amplit.^2 - b;
    abs_res .= abs.(res);
    obj = mean(abs_res);
    objs = cat(objs, obj, dims=1);#some change happens here
    # if mod(iter,100)==0
    #   println(obj)
    # end
    rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
  end
  total_iters=iter;
  return (x_curr, objs, total_iters);
  end
