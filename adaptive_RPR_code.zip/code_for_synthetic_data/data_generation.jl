using Random
using Statistics
using LinearAlgebra
using DelimitedFiles
using StatsBase
function data_generation(
    nn::Int64 = 1500,
    dd::Int64 = 1500,
    p_fail::Float64 = 0.1,
    fail_multi::Float64 = 1.0,
    num_n_vals::Int64 = 16,#Before this generation, there are num_n_vals-1 generations in total
    seed::Int64 = 2017,
    min_eig::Float64 = 1.0)
    Random.seed!(seed);
    n_fail=round(Int64, nn * p_fail);
    cov_diag = collect(range(1, stop = min_eig, length = dd));
    cov_diag .= sqrt.(cov_diag);
    cov_diag = Diagonal(cov_diag);
    A = zeros(nn,dd);
    b = zeros(nn);
    x = zeros(dd);
    for i in range(1,stop=num_n_vals)
        x .= randn(dd);
        x .= sign.(x);
        A .= randn(nn, dd)*cov_diag;
        b .= (A * x).^2;
        if n_fail>0
            fail_inds = sample(1:nn, n_fail; replace=false);
            #median of corruption equals to the median of b_true
            corruptions=tan.((pi/2-1e-10)*rand(n_fail)) .* median(b) .* fail_multi;
            b[fail_inds] .= corruptions;
        end
    end
    return (A,b,x)
end
