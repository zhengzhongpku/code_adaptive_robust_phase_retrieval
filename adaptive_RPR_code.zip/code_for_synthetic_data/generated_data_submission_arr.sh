#!/bin/bash

#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=48:00:00
#SBATCH --mem=4GB
#SBATCH --partition=open
#SBATCH --mail-type=NONE

cd /storage/work/zvz5337/IPL_diminishing_0829/generated_hete_additional_algs_1129/
command_final="julia /storage/work/zvz5337/IPL_diminishing_0829/generated_hete_additional_algs_1129/pipeline2_arr.jl ${command1}"
eval "${command_final}"
