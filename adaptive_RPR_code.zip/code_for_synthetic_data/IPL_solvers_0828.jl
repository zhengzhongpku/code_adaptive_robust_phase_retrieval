#This function introduces the IPL solvers one the robust phase retrieval problem based on simulated datasets.
#The constants in this function are tuned based on the following settings. 
#1. A = randn(nn,dd) for the homogeneous setting. When condition number>1, the largest singular value keeps the same.
#2. x_star is generated from {-1,1}^nn so that \|x_\star\|_2 = sqrt(dd). Correspondingly we can get b. x_init is the initial
#   estimation of x_true.
#3. alg is a string that only takes "low", "high" and "pd" as inputs.
#4. update_tol, loss_tol and rel_error_tol are thresholds for terminating the iterations based on x_true and loss_opt.
#5. max_iter_main/max_iter_sub represents the (max number of main iterations) or (max number of one subproblem iteration).
#6. max_sub_hit is the maximum times of subproblem iteration numbers hitting maxiter_sub.
#7. rho_coeff is the rho_l or rho_h in the paper.
#8. G_stepsize is the G for diminishing step sizes when \|x_\star\|_2 = 1. Explanation will be provided for scaling it in the
#   code when \|x_\star\|_2 = sqrt(dd).
#9. if_diminishing/if_warmstart/if_erg are indicators for whether these tricks will be used. Erg only affects low and high.


function IPL_solvers_simulate(A::Matrix{Float64}, b::Vector{Float64}, alg_sub::String, alg_stop::String;
    x_init::Vector{Float64} = randn(size(A, 2)),
    update_tol::Float64 = -1.0,
    loss_tol::Float64 = -1.0,
    rel_error_tol::Float64 = -1.0,
    loss_opt::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),

    maxiter_main::Int64 = 200,
    maxiter_sub::Int64 = 2000,
    max_sub_hit::Int64 = 4,

    rho_coeff::Float64 = 0.24,
    G_stepsize::Float64 = 10.0,
    
    if_diminishing::Int64 = 1,
    if_warmstart::Int64 = 1,
    if_erg::Int64 = 0,
    
    if_verbose::Int64 = 0,
    opnorm_A::Float64 = -1.0)
    ##############################################################
    ##############################################################
    if ~((alg_stop == "low")||(alg_stop == "high"))
        error("alg_stop not in the candicates")
    end
    if ~((alg_sub == "fista")||(alg_sub == "pd"))
        error("alg_sub not in the candicates")
    end
    x_curr = copy(x_init);
    (nn, dd) = size(A);
    if opnorm_A < 0
        opnorm_A = opnorm(A);
    end
    lipschitz_const = 2 / nn * opnorm_A^2;
    iter_main = 0;
    total_iters = 0;
    objs = [];
    iter_count=0;
    Ax_curr = A * x_curr;
    resid = Ax_curr.^2 - b;
    obj=mean(abs.(resid));
    steplength=Inf;

    lambda_init=zeros(nn);
    subiter_limit_count=0;
    objs = cat(objs, obj, dims=1);
    rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
    x_update = zeros(dd);
    matmul_total0 = 0;
    while ((iter_main < maxiter_main) && (obj>loss_tol) && (steplength > update_tol) && (rel_error>rel_error_tol))
        t_current = 1/lipschitz_const;
        if if_diminishing == 1
            abs_resid = abs.(resid);
            med_resid = median(abs_resid);
            t_current = min(1/lipschitz_const, med_resid/dd*G_stepsize);
            #Here we explain why we need a dd in the denominator. There stepsize we need is Omega(delta(x)/lambda_s) when
            #F(x) - F(x_\star) = Omega(lambda_s*delta(x)). As lambda_s = Omega(\|x_star\|_2), we make a scaling of dd.
        end
        #inner_grad_mat = diagm((2* t_current / nn) * Ax_curr) * A; #t_kB_k #diagm creates a dense one
        inner_grad_mat = Diagonal((2* t_current / nn) * Ax_curr) * A; #t_kB_k #Diagonal creates a sparse one
        inner_resid_vec = (-t_current / nn) * resid;
        #The primal problem is (1/2)||z||_2^2 + ||inner_grad_mat*z - inner_resid_vec||_1
        #The negative dual problem is (1/2)||inner_grad_mat^T(times)lambda||_2^2 + inner_resid_vec^T(times)lambda 
        #with ||lambda||_infty<1.
        if (alg_sub == "fista")
            stepsize = 32*nn^2/(t_current^2)/median(b)/(opnorm_A^2); #initial step size for solving the dual subproblem.
            #The accurate one should be 1/||inner_grad_mat||_2^2 approx nn^2/(2 * t_current)^2/||Ax_curr||_inf^2/||A||_2^2, 
            #which equals to 4*nn^2/t_current^2/||Ax_curr^2||_inf/opnorm_A^2. After replacing ||Ax_curr^2||_inf with median(b),
            #we get the result.
            (x_update, iter_count, lambda_init, matmul_total) = Fista_dual_simulate(inner_grad_mat, 
            inner_resid_vec, alg_stop, MAXITER = maxiter_sub,
            rho_coeff = rho_coeff, t_init=stepsize, lambda_init=lambda_init, if_warmstart = if_warmstart,
            if_erg = if_erg);
            matmul_total0 = matmul_total0 + matmul_total;
        end

        if alg_sub == "pd"
            rough_norm_B = (2* t_current / nn) * norm(Ax_curr, Inf) * opnorm_A;
            (x_update, iter_count, lambda_init) = PD_simulate(inner_grad_mat, 
            inner_resid_vec, alg_stop,
            MAXITER = maxiter_sub,
            rho_coeff = rho_coeff,
            z_init = x_update,
            lambda_init = lambda_init,
            rough_norm_Bk = rough_norm_B,
            if_warmstart = if_warmstart)
        end


        total_iters += iter_count;
        x_curr .= x_curr .+ x_update;
        rel_error = min(norm(x_true - x_curr),norm(x_true + x_curr))/norm(x_true);
        iter_main = iter_main + 1;
        if update_tol>0
            grad_map = x_update/t_current;
            steplength = norm(grad_map)
        end
        mul!(Ax_curr, A, x_curr);
        resid .= Ax_curr.^2 .- b;
        obj = mean(abs.(resid));
        objs = cat(objs, obj, dims=1);
        if if_verbose == 1
            println("Iteration: ", iter_main, ", rel_error: ", rel_error, ", subiter: ", iter_count, ", matmul: ", matmul_total,
                    ", steplength: ", norm(x_update), ", loss gap: ", obj-loss_opt, ", stepsize: ", t_current);
        end
        if iter_count>=maxiter_sub-1
            subiter_limit_count=subiter_limit_count+1;
        end
        if subiter_limit_count >= max_sub_hit
            break;
        end
    end
    if if_verbose == 1
        println("matmul_total0: ", matmul_total0)
    end
    return (x_curr, objs, total_iters, iter_main);
end

function Fista_dual_simulate(B_mat::Matrix{Float64}, d_vec::Vector{Float64}, alg::String;
    MAXITER::Int64 = 2000,
    rho_coeff::Float64 = 0.24,
    t_init::Float64 = 1.0,#initial step size
    lambda_init::Vector{Float64} = zeros(size(d_vec))[1],
    if_warmstart::Int64 = 1,
    if_erg::Int64 = 0
    )
    ###################################
    ###################################
    t=t_init;
    loss_init=norm(d_vec, 1);
    nn = length(d_vec);
    dd = size(B_mat, 2);
    BT = B_mat';
    iter = 0;
    matmul_total = 0;

    #lambda_init = zeros(nn);

    lambda_x=zeros(nn);
    lambda_y=zeros(nn);
    lambda_x_record=zeros(nn);
    lambda_y_record=zeros(nn);
    lambda_z=zeros(nn);
    if if_warmstart == 1
        lambda_x .= lambda_init;
        lambda_y .= lambda_init;
        lambda_x_record .= lambda_init;
        lambda_y_record .= lambda_init;
        lambda_z .= lambda_init;

    end

    x = zeros(dd);
    y = zeros(nn);
    x_alt = zeros(dd);
    d_minus_y=zeros(nn);
    temp1 = zeros(nn);

    if if_erg == 1
        x_erg = zeros(dd);
        y_erg = zeros(nn);
        d_minus_y_erg=zeros(nn);
        x_erg_num = zeros(dd);
        y_erg_num = zeros(nn);
        erg_denom = 0.0;
    end


    gamma=1.0;

    x_best = zeros(dd);
    lambda_best = zeros(nn);

    #lambda_z .= (1-gamma) .* lambda_x .+ gamma .* lambda_y;
    mul!(x, BT, lambda_z, -1, false);
    mul!(y, B_mat, x);
    matmul_total = matmul_total + 2;
    d_minus_y .= d_vec .- y;
    loss_primal = 0.5*norm(x)^2+norm(d_minus_y,1);
    loss_dual = 0.5*norm(x)^2+dot(lambda_z,d_vec);
    loss_primal_best = loss_primal;
    loss_dual_best = loss_dual;
    x_best .= x;
    lambda_best .= lambda_z;
    loss_gap = loss_primal + loss_dual;
    loss_decrease = loss_init - loss_primal;

    while (iter < MAXITER)
        if alg == "low"
            if (loss_gap <= rho_coeff*loss_decrease)
                break
            end
        end

        if alg == "high"
            if (loss_gap <= rho_coeff/2*norm(x_best)^2)
                break
            end
        end
        lambda_z .= (1-gamma) .* lambda_x .+ gamma .* lambda_y;
        mul!(x, BT, lambda_z, -1, false);
        mul!(y, B_mat, x);
        matmul_total = matmul_total + 2;
        d_minus_y .= d_vec .- y;
        loss_primal = 0.5*norm(x)^2+norm(d_minus_y,1);
        if loss_primal < loss_primal_best
            loss_primal_best = loss_primal;
            x_best .= x
        end

        loss_dual = 0.5*norm(x)^2+dot(lambda_z,d_vec);
        if loss_dual < loss_dual_best
            loss_dual_best = loss_dual;
            lambda_best .= lambda_z;
        end
        if if_erg == 1
            x_erg_num .= x_erg_num .+ (1/gamma) .* x;
            y_erg_num .= y_erg_num .+ (1/gamma) .* y;
            erg_denom = erg_denom + (1/gamma);
            x_erg .= x_erg_num ./ erg_denom;
            y_erg .= y_erg ./ erg_denom;
            d_minus_y_erg .= d_vec .- y_erg;
            loss_primal = 0.5*norm(x_erg)^2+norm(d_minus_y_erg,1);
            if loss_primal < loss_primal_best
                loss_primal_best = loss_primal;
                x_best .= x_erg;
            end
        end


        for counting in 0:100
            shrink=0.5^counting;
            lambda_y .= lambda_y_record .- (shrink*t/gamma) .* d_minus_y;
            lambda_y[lambda_y .> 1.0] .= 1.0;
            lambda_y[lambda_y .< -1.0] .= -1.0;
            lambda_x .= (1-gamma) .* lambda_x_record .+ gamma .* lambda_y;
            mul!(x_alt, BT, lambda_x, -1, false);
            matmul_total = matmul_total + 1;
            temp1 .= lambda_x .- lambda_z;
            if (norm(x_alt - x)^2 <= 1/shrink/t*norm(temp1)^2)
                lambda_x_record .= lambda_x;
                lambda_y_record .= lambda_y;
                t=t*shrink;
                break;
            end
        end

        loss_dual = 0.5*norm(x_alt)^2+dot(lambda_x,d_vec);
        if loss_dual < loss_dual_best
            loss_dual_best = loss_dual;
            lambda_best .= lambda_x;
        end


        gamma=2/(1+sqrt(1+4/(gamma^2)));
        loss_decrease = loss_init - loss_primal_best;
        loss_gap = loss_primal_best + loss_dual_best;
        iter += 1;
        end

    return (x_best, iter, lambda_best, matmul_total);
end



function PD_simulate(B::Matrix{Float64}, d::Vector{Float64},alg::String;
    MAXITER::Int64 = 20000,
    rho_coeff::Float64 = 0.24,
    z_init::Vector{Float64} = zeros(size(B)[2]),
    lambda_init::Vector{Float64} = zeros(size(d)[1]),
    rough_norm_Bk::Float64 = 1.0,
    if_warmstart::Int64 = 1)
    ###################################################
    ###################################################
    mu = 1.0;
    loss_init=norm(d, 1);
    nn = length(d);
    dd = size(B, 2);
    BT = zeros(dd,nn);
    BT .= B';


    if if_warmstart == 0
        z_init = zeros(dd);
        lambda_init = zeros(nn);
    end
    # mul!(z_init, BT, lambda_init, -1, false);
    # tau_pre = 0.2;
    # sigma_pre = 200/(rough_norm_Bk^2);

    tau_pre = 1.0;
    sigma_pre = 10.0/(rough_norm_Bk^2);

    # tau_pre = 10/(rough_norm_Bk);
    # sigma_pre = 10.0/(rough_norm_Bk);

    eta = 0.5;
    gamma_pre = sigma_pre/tau_pre;

    z_current = zeros(dd); z_current .= z_init;
    z_temp = zeros(dd);
    z_erg = zeros(dd);
    z_best = zeros(dd); z_best .= z_init;


    Bz_pre = zeros(nn); mul!(Bz_pre,B,z_current);
    Bz_current = zeros(nn); Bz_current .= Bz_pre;
    Bz_middle = zeros(nn);
    Bz_temp = zeros(nn);
    Bz_erg = zeros(nn);


    lambda_temp = zeros(nn);
    lambda_current = zeros(nn); lambda_current .= lambda_init;
    lambda_erg = zeros(nn);
    lambda_best = zeros(nn); lambda_best .= lambda_init;

    BTlambda_temp = zeros(dd);
    BTlambda_current = zeros(dd); mul!(BTlambda_current, BT, lambda_current);
    BTlambda_erg = zeros(dd);

    loss_decrease = 0.0;
    loss_primal_best = 1/2*norm(z_current)^2 + norm(Bz_current - d,1);
    loss_dual_best = -1/2*norm(BTlambda_current)^2 - dot(d,lambda_current);
    loss_primal_current = loss_primal_best;
    loss_dual_current = loss_dual_best;
    loss_gap_best = loss_primal_best - loss_dual_best;

    loss_gap = Inf;
    Tk = 0.0;
    iter = 0;
    while (iter < MAXITER)
        if alg == "low"
            if (loss_gap <= rho_coeff*loss_decrease)
                break
            end
        end

        if alg == "high"
            if (loss_gap <= rho_coeff/2*norm(z_best)^2)
                break
            end
        end
        primal_erg_best = 0;
        dual_erg_best = 0;
        gamma = gamma_pre * (1 + mu * tau_pre);
        tau = tau_pre * sqrt(gamma_pre/gamma)
        for counting in 0:20
            tau_temp = tau*(eta^counting);
            sigma = gamma*tau_temp;
            theta = sigma_pre/sigma;
            Bz_middle .= Bz_current .+ theta .* (Bz_current - Bz_pre);
            lambda_temp .= sigma .* (Bz_middle .- d);
            lambda_temp[lambda_temp .> 1.0] .= 1.0;
            lambda_temp[lambda_temp .< -1.0] .= -1.0;
            mul!(BTlambda_temp, BT, lambda_temp);
            z_temp .= (1/(1+tau_temp)) .* z_current .- (tau_temp/(1+tau_temp)) .* BTlambda_temp;
            mul!(Bz_temp, B, z_temp);
            if sqrt(sigma* tau_temp) * norm(Bz_temp - Bz_current) <=  norm(z_temp - z_current) + 3e-16
                lambda_current .= lambda_temp;
                BTlambda_current .= BTlambda_temp;
                z_current .= z_temp;
                Bz_pre .= Bz_current;
                mul!(Bz_current,B,z_current);
                tau_pre = tau_temp;
                gamma_pre = gamma;
                sigma_pre = sigma;
                loss_primal_current = 1/2*norm(z_current)^2 + norm(Bz_current - d,1);
                loss_dual_current = -1/2*norm(BTlambda_current)^2 - dot(d,lambda_current);
                break;
            end
        end
        z_erg .= Tk .* z_erg .+ sigma_pre .* z_current;
        lambda_erg .= Tk .* lambda_erg .+ sigma_pre .* lambda_current;
        Bz_erg .= Tk .* Bz_erg .+ sigma_pre .* Bz_current;
        BTlambda_erg .= Tk .* BTlambda_erg .+ sigma_pre .* BTlambda_current;
        Tk = Tk + sigma_pre;
        z_erg .= z_erg ./ Tk;
        lambda_erg .= lambda_erg ./ Tk;
        Bz_erg .= Bz_erg ./ Tk;
        BTlambda_erg .= BTlambda_erg ./ Tk;
        loss_primal_erg = 1/2*norm(z_erg)^2 + norm(Bz_erg - d,1);
        loss_dual_erg = -1/2*norm(BTlambda_erg)^2 - dot(d,lambda_erg);


        loss_gap_new = min(loss_gap_best, loss_primal_current - loss_dual_current, loss_primal_erg - loss_dual_erg);
        if loss_gap_new < loss_gap_best
            if loss_gap_new == loss_primal_current - loss_dual_current;
                z_best .= z_current;
                lambda_best .= lambda_current;
                loss_primal_best = loss_primal_current;
                loss_dual_best = loss_dual_current;
            else
                z_best .= z_erg;
                primal_erg_best = 1;
                lambda_best .= lambda_erg;
                dual_erg_best = 1;
                loss_primal_best = loss_primal_erg;
                loss_dual_best = loss_dual_erg;
            end
        end

        loss_decrease = loss_init - loss_primal_best;
        loss_gap = loss_primal_best - loss_dual_best;
        iter = iter + 1;
        # if mod(iter,10)==0
        #     println("iter: ",iter, ", loss decrease: ", loss_decrease, ", loss gap: ", loss_gap,
        #             ", erg best: ", primal_erg_best, dual_erg_best);
        #     println("tau: ", tau_pre, ", sigma: ", sigma_pre, ", mulre: ", tau_pre*sigma_pre*(rough_norm_Bk^2));
        # end

    end
    return (z_best, iter, lambda_best);
end
