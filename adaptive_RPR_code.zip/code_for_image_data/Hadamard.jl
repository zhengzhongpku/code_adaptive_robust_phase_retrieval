# Hadamard.jl
#
# Methods for simple Hadamard matrix multiplication

module Hadamard

export intlog, hadmat, hadmult, hadmult!;

# hadmat(k)
#
# constructs the 2^k-by-2^k Hadamard matrix
function hadmat(k)
  H = [1.0 1.0; 1.0 -1.0];
  for ii = 1:(k-1)
    H = [H H; H -H];
  end
  return H;
end

# log_val = intlog(nn:Int64)
#
# Computes the base-2 integer logarithm, that is, floor(Int64, log2(nn)), but
# is approximately twice as fast as floor(Int64, log2(nn)).
function intlog(nn::Int64)
  log_val = 0;
  while (nn > 0)
    log_val += 1;
    nn = nn>>1;
  end
  return log_val - 1;
end

# hadmult!(v::Vector{Float64})
#
# Computes the fast Walsh-Hadamard transform, with +/-1 matrix, and applies it
# in place to the vector v. This is *not* normalized.
function hadmult!(v::Vector{Float64})
  log_size = intlog(length(v));
  tmp = 0.0;
  v_len = 1 << log_size;
  v_increment = 0;
  j_increment = 0;
  @inbounds for ii = 0:(log_size-1)
    jj = 0;
    v_increment = (1 << ii);
    j_increment = (1 << (ii + 1));
    while (jj < v_len)
      k_len = 1 << ii;
      for kk = 0:(k_len-1)
        tmp = v[1 + jj + kk];
        v[1 + jj + kk] += v[1 + jj + kk + v_increment];
        v[1 + jj + kk + v_increment] = tmp - v[1 + jj + kk + v_increment];
      end
      jj += j_increment;
    end
  end
end

# hadmult!(v::SubArray{Float64,1,Array{Float64,1},Tuple{UnitRange{Int64}},true})
#
# Computes the fast Walsh-Hadamard transform, with +/-1 matrix, and applies it
# in place to the vector v. This is *not* normalized.
function hadmult!(v::SubArray{Float64,1,Array{Float64,1},
                              Tuple{UnitRange{Int64}},true})
  log_size = intlog(length(v));
  tmp = 0.0;
  v_len = 1 << log_size;
  v_increment = 0;
  j_increment = 0;
  @inbounds for ii = 0:(log_size-1)
    jj = 0;
    v_increment = (1 << ii);
    j_increment = (1 << (ii + 1));
    while (jj < v_len)
      k_len = 1 << ii;
      for kk = 0:(k_len-1)
        tmp = v[1 + jj + kk];
        v[1 + jj + kk] += v[1 + jj + kk + v_increment];
        v[1 + jj + kk + v_increment] = tmp - v[1 + jj + kk + v_increment];
      end
      jj += j_increment;
    end
  end
end

# hadmult!(v::Vector{Float32})
#
# Computes the fast Walsh-Hadamard transform, with +/-1 matrix, and applies it
# in place to the vector v. This is *not* normalized.
function hadmult!(v::Vector{Float32})
  log_size = intlog(length(v));
  tmp = Float32(0.0);
  v_len = 1 << log_size;
  v_increment = 0;
  j_increment = 0;
  @inbounds for ii = 0:(log_size-1)
    jj = 0;
    v_increment = (1 << ii);
    j_increment = (1 << (ii + 1));
    while (jj < v_len)
      k_len = 1 << ii;
      for kk = 0:(k_len-1)
        tmp = v[1 + jj + kk];
        v[1 + jj + kk] += v[1 + jj + kk + v_increment];
        v[1 + jj + kk + v_increment] = tmp - v[1 + jj + kk + v_increment];
      end
      jj += j_increment;
    end
  end
end

# hadmult!(v::SubArray{Float32,1,Array{Float64,1},Tuple{UnitRange{Int64}},true})
#
# Computes the fast Walsh-Hadamard transform, with +/-1 matrix, and applies it
# in place to the vector v. This is *not* normalized.
function hadmult!(v::SubArray{Float32,1,Array{Float32,1},
                              Tuple{UnitRange{Int64}},true})
  log_size = intlog(length(v));
  tmp = Float32(0.0);
  v_len = 1 << log_size;
  v_increment = 0;
  j_increment = 0;
  @inbounds for ii = 0:(log_size-1)
    jj = 0;
    v_increment = (1 << ii);
    j_increment = (1 << (ii + 1));
    while (jj < v_len)
      k_len = 1 << ii;
      for kk = 0:(k_len-1)
        tmp = v[1 + jj + kk];
        v[1 + jj + kk] += v[1 + jj + kk + v_increment];
        v[1 + jj + kk + v_increment] = tmp - v[1 + jj + kk + v_increment];
      end
      jj += j_increment;
    end
  end
end

# x = hadmult(v::Vector{Float64})
#
# Computes and returns the product of the Hadamard matrix with v.
function hadmult(v::Vector{Float64})
  tmp = copy(v);
  hadmult!(tmp);
  return tmp;
end

# x = hadmult(v::Vector{Float32})
#
# Computes and returns the product of the Hadamard matrix with v.
function hadmult(v::Vector{Float32})
  tmp = copy(v);
  hadmult!(tmp);
  return tmp;
end

# hadmult!(v::Vector)
#
# Computes the fast Walsh-Hadamard transform, with +/-1 matrix, and applies it
# in place to the vector v. This is *not* normalized.
function hadmult!(v::Vector)
  log_size = intlog(length(v));
  tmp = typeof(v[1])(0);
  v_len = 1 << log_size;
  v_increment = 0;
  j_increment = 0;
  @inbounds for ii = 0:(log_size-1)
    jj = 0;
    v_increment = (1 << ii);
    j_increment = (1 << (ii + 1));
    while (jj < v_len)
      k_len = 1 << ii;
      for kk = 0:(k_len-1)
        tmp = v[1 + jj + kk];
        v[1 + jj + kk] += v[1 + jj + kk + v_increment];
        v[1 + jj + kk + v_increment] = tmp - v[1 + jj + kk + v_increment];
      end
      jj += j_increment;
    end
  end
end

end  # module Hadamard
