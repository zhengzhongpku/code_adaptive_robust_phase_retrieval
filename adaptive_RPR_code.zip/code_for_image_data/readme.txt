The provided code generates the experiments (image data) in Section 8.2 in [1].

[1] Zheng, Z., Aybat, N. S., Ma, S., & Xue, L. (2024). Adaptive Algorithms for Robust Phase Retrieval. arXiv preprint arXiv:2409.19162.


Part One: How to run the code.

We explain the procedure by the following example.

# include all the julia files in this directory except pipeline2_arr.jl.
# fail_multi_index = 1;
# p_fail_index = 4;
# kk_index = 1;
# rep_index = 0;
# code_num = fail_multi_index + p_fail_index*10 + kk_index*100 + rep_index*1000 + 100000;
# generated_pipeline(100141);


In this example, we use "code_num" to represent one experiment. Here, fail_multi_index indexes the type of corruptions, p_fail_index indexes pfail in our paper.
dd indexes n in our paper, kk indexes m/n in our paper, rep_index indexes the replication id of our paper. For the detailed mapping, please refer to main_file.
The result will be written to a text file in the folder "result".

The two files with extension .sh together with task_file_gen.py and mkdir_1021.jl provide a way to parallel the tasks in a multi-core machine. If you use this, remember to change the path.

Part Two: explanation of key files:

data_generation_1021.jl: generating A and b in our paper.
Initializer_1021.jl: initiailization based on Duchi and Ruan's method in [2].
IPL_solvers_0830.jl: code for IPL and AdaIPL.
main_file.jl: the main file that contains the function generated_pipeline() to compare all the methods.
solver_subgradient_median_1021.jl: code for AdaSubgrad.
solver_subgradient_1021.jl: code for the subgradient method with geometrically decaying step sizes used in [3]
solver_two_stage_pogs_1021.jl: code for PL in [1].
utility_functions_1021.jl, Hadamard.jl: utility functions used in this procedure.


[2] Duchi, J. C., & Ruan, F. (2019). Solving (most) of a set of quadratic equalities: Composite optimization for robust phase retrieval. Information and Inference: A Journal of the IMA, 8(3), 471-529.
[3] Davis, D., Drusvyatskiy, D., MacPhee, K. J., & Paquette, C. (2018). Subgradient methods for sharp weakly convex functions. Journal of Optimization Theory and Applications, 179, 962-982.

