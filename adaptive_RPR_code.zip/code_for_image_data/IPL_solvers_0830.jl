#This function introduces the IPL solvers one the robust phase retrieval problem based on image datasets.
#The constants in this function are tuned based on the following settings. 
#1. mulHS: this function multiplies HS to a vector. kk = nn/dd. H represents a nn by nn block-diagnoal matrix where
#   each block equals to tilde(H)/sqrt{dd}, in which tilde(H) is the dd-dimensional matrix consisting of 1 or -1. The
#   multiplier 1/sqrt(dd) is used to scale the matrix to make it orthogonal. The nn-dimensional vector s belongs to
#   {1,-1}^nn/sqrt{kk}. Let A/sqrt{nn} = HS, we can find that the RHS has a norm 1.

#2. x_true is obtained from a image, so that we expect its norm to be c*sqrt(dd) in which c is a small constant.
function IPL_solvers_image(x_init::Vector{Float64},
    s_vec::Vector{Float64},
    b::Vector{Float64}, alg_sub::String, alg_stop::String;
    update_tol::Float64 = -1.0,
    loss_tol::Float64 = -1.0,
    rel_error_tol::Float64 = -1.0,
    loss_opt::Float64 = -1.0,
    x_true::Vector{Float64} = randn(size(A, 2)),

    maxiter_main::Int64 = 200,
    maxiter_sub::Int64 = 2000,
    max_sub_hit::Int64 = 4,

    rho_coeff::Float64 = 0.24,
    G_stepsize::Float64 = 100.0,
    
    if_diminishing::Int64 = 1,
    if_warmstart::Int64 = 1,
    if_erg::Int64 = 0,
    
    if_verbose::Int64 = 0)
    #################################
    dd=length(x_init);
    nn=length(s_vec);
    kk=round(Int64,nn/dd);
    x_curr = copy(x_init);
    if (2^Hadamard.intlog(dd) != dd)
        error("Dimension must be power of 2.");
    end
    b_vec = copy(b);
    iter_main = 0;
    total_iters = 0;
    grad_map_norm = Inf;
    objs = zeros(maxiter_main+1);
    Wx = zeros(nn);
    grad_map=zeros(dd);
    
    x_delta = zeros(dd);
    d_work_vec = zeros(dd);
    opnorm_A = 1.0;
    lipschitz_const = 2 * opnorm_A^2;
    #stepsize=20/(sqrt(median(b))/opnorm_A);
    MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
    c_vec =  b_vec .- (Wx).^2;
    D_sub = zeros(nn);
    subiter_count=0;
    lambda_init=zeros(nn);
    obj = norm(c_vec,1);
    objs[1] = obj
    sub_limit_count=0;
    rel_error = min(norm(x_curr - x_true) / norm(x_true), norm(x_curr + x_true) / norm(x_true));
    steplength=Inf;
    abs_resid = zeros(nn);
    inner_resid_vec = zeros(nn);
    x_delta = zeros(dd);
    if if_verbose == 1
        println("Iteration: ", 0, ", rel_error: ", rel_error, ", subiter: ", 0, ", loss gap: ", obj-loss_opt);
    end
    while ((iter_main < maxiter_main) && (obj > loss_tol) && (steplength > update_tol) && (rel_error>rel_error_tol))
        t_current = 1/lipschitz_const;
        if if_diminishing == 1
            abs_resid .= abs.(c_vec);
            med_resid = median(abs_resid);
            t_current = min(1/lipschitz_const, nn*med_resid/dd*G_stepsize);
            #Here we explain why we need nn and dd here. The mapping of HS is of norm 1 so that we
            #need nn here. For dd, the stepsize we need is Omega(delta(x)/lambda_s) when
            #F(x) - F(x_\star) = Omega(lambda_s*delta(x)). As lambda_s = Omega(\|x_star\|_2), we make a scaling of dd.
        end
        D_sub .= (2*t_current) .* Wx;
        inner_resid_vec .= t_current .* c_vec;
        if (alg_sub == "fista")
            stepsize=32/(t_current^2)/median(b)/(opnorm_A^2);#initial step size for solving the dual subproblem.
            #The accurate one should be 1/||inner_grad_mat||_2^2. Please refer to the simulated case for detail.
            (x_delta, subiters, lambda_init) = Fista_dual_image(dd, s_vec, D_sub,
            inner_resid_vec, alg_stop, MAXITER = maxiter_sub,
            rho_coeff = rho_coeff, t_init=stepsize, lambda_init=lambda_init, if_warmstart = if_warmstart,
            if_erg = if_erg);
        end
        if alg_sub == "pd"
            rough_norm_B = (2* t_current) * norm(Wx, Inf) * opnorm_A;
            (x_delta, subiters, lambda_init) = PD_image(dd, s_vec, D_sub,
            inner_resid_vec, alg_stop,
            MAXITER = maxiter_sub,
            rho_coeff = rho_coeff,
            z_init = x_delta,
            lambda_init = lambda_init,
            rough_norm_Bk = rough_norm_B,
            if_warmstart = if_warmstart)
        end
        



        subiter_count += subiters;
        grad_map .= (lipschitz_const/2) .* x_delta;
        x_curr .= x_curr .+ x_delta;
        grad_map_norm = Inf;
        if update_tol > 0
            grad_map_norm = norm(grad_map);
        end
        iter_main = iter_main + 1;
        MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
        c_vec .= b_vec .- Wx.^2;
        obj = norm(c_vec, 1);
        objs[iter_main+1] = obj;
        rel_error = min(norm(x_curr - x_true) / norm(x_true), norm(x_curr + x_true) / norm(x_true));
        if if_verbose == 1
            println("Iteration: ", iter_main, ", rel_error: ", rel_error, ", subiter: ", subiters,
                    ", steplength: ", norm(grad_map), ", loss gap: ", obj-loss_opt, ", stepsize: ", t_current);
        end
        if subiters >= maxiter_sub-1
            sub_limit_count=sub_limit_count+1;
        end
        if sub_limit_count>=max_sub_hit
            break;
        end
    end
    objs = objs[1:(iter_main+1)];
    return (x_curr, objs, subiter_count, iter_main);

end

function Fista_dual_image(dd::Int64, s_vec::Vector{Float64},
    D::Vector{Float64}, c_vec::Vector{Float64}, alg::String;
    MAXITER::Int64 = 2000,
    rho_coeff::Float64 = 0.24,
    t_init::Float64 = 1.0,#initial step size
    lambda_init::Vector{Float64} = zeros(size(d_vec))[1],
    if_warmstart::Int64 = 1,
    if_erg::Int64 = 0
    )
    #####################################
    s_vec_neg = -s_vec;
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    t=t_init;
    loss_init=norm(c_vec, 1);
    iter = 0;
    lambda_x=zeros(nn);
    lambda_y=zeros(nn);
    lambda_x_record=zeros(nn);
    lambda_y_record=zeros(nn);
    lambda_z=zeros(nn);
    if if_warmstart == 1
        lambda_x .= lambda_init;
        lambda_y .= lambda_init;
        lambda_x_record .= lambda_init;
        lambda_y_record .= lambda_init;
        lambda_z .= lambda_init;
    end
    x=zeros(dd);
    y=zeros(nn);
    c_minus_y=zeros(nn);

    x_alt = zeros(dd);
    if if_erg == 1
        x_erg = zeros(dd);
        y_erg = zeros(nn);
        c_minus_y_erg=zeros(nn);
    end



    temp1 = zeros(nn);
    temp2 = zeros(dd);
    gamma=1.0;
    loss_primal_part1=0.0;
    loss_primal_part2=0.0;
    loss_primal=loss_primal_part1+loss_primal_part2;
    loss_decrease=0.0;
    loss_gap=Inf;
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);

    loss_primal_best = 0.0;
    loss_dual_best = 0.0;
    x_best = zeros(dd);
    lambda_best = zeros(nn);

    #mul!(x, AT, lambda_z, -1, false)
    MultiplyByDHST!(lambda_z, s_vec_neg, D, n_work_vec, x);
    #mul!(y,A,x);
    MultiplyByDHS!(x, s_vec, D, d_work_vec, y);
    c_minus_y .= c_vec .- y;

    loss_primal = 0.5*norm(x)^2+norm(c_minus_y,1);
    loss_dual = 0.5*norm(x)^2+dot(lambda_z,c_vec);
    loss_primal_best = loss_primal;
    loss_dual_best = loss_dual;
    x_best .= x;
    lambda_best .= lambda_z;
    loss_gap = loss_primal + loss_dual;
    loss_decrease = loss_init - loss_primal;
    if if_erg == 1
        x_erg_num = zeros(dd);
        y_erg_num = zeros(nn);
        erg_denom = 0.0;
    end


    while (iter < MAXITER)
        if alg == "low"
            if (loss_gap <= rho_coeff*loss_decrease)
                break
            end
        end

        if alg == "high"
            if (loss_gap <= rho_coeff/2*norm(x_best)^2)
                break
            end
        end
        lambda_z .= (1-gamma) .* lambda_x .+ gamma .* lambda_y;
        #mul!(x, AT, lambda_z, -1, false)
        MultiplyByDHST!(lambda_z, s_vec_neg, D, n_work_vec, x);
        #mul!(y,A,x);
        MultiplyByDHS!(x, s_vec, D, d_work_vec, y);
        c_minus_y .= c_vec .- y;


        loss_primal = 0.5*norm(x)^2+norm(c_minus_y,1);
        if loss_primal < loss_primal_best
            loss_primal_best = loss_primal;
            x_best .= x
        end

        loss_dual = 0.5*norm(x)^2+dot(lambda_z,c_vec);
        if loss_dual < loss_dual_best
            loss_dual_best = loss_dual;
            lambda_best .= lambda_z;
        end

        if if_erg == 1
            x_erg_num .= x_erg_num .+ (1/gamma) .* x;
            y_erg_num .= y_erg_num .+ (1/gamma) .* y;
            erg_denom = erg_denom + (1/gamma);
            x_erg .= x_erg_num ./ erg_denom;
            y_erg .= y_erg ./ erg_denom;
            c_minus_y_erg .= c_vec .- y_erg;
            loss_primal = 0.5*norm(x_erg)^2+norm(c_minus_y_erg,1);
            if loss_primal < loss_primal_best
                loss_primal_best = loss_primal;
                x_best .= x_erg;
            end
        end

        for counting in 0:100
          shrink=0.5^counting;
          lambda_y .= lambda_y_record .- (shrink*t/gamma) .* c_minus_y;
          lambda_y[lambda_y .> 1.0] .= 1.0;
          lambda_y[lambda_y .< -1.0] .= -1.0;
          lambda_x .= (1-gamma) .* lambda_x_record .+ gamma .* lambda_y;
          temp1 .= lambda_x .- lambda_z;
          #mul!(x_alt, AT, lambda_x, -1, false);
          MultiplyByDHST!(lambda_x, s_vec_neg, D, n_work_vec, x_alt);
          #mul!(temp2, AT, temp1);
          MultiplyByDHST!(temp1, s_vec, D, n_work_vec, temp2);
          if (norm(x_alt - x)^2 <= 1/shrink/t*norm(temp1)^2)
            lambda_x_record .= lambda_x;
            lambda_y_record .= lambda_y;
            t=t*shrink;
            break;
          end
        end

        loss_dual = 0.5*norm(x_alt)^2+dot(lambda_x,c_vec);
        if loss_dual < loss_dual_best
            loss_dual_best = loss_dual;
            lambda_best .= lambda_x;
        end
        gamma=2/(1+sqrt(1+4/(gamma^2)))
        # loss_primal_part1=0.5*norm(x)^2;
        # loss_primal_part2=norm(c_minus_y,1);
        # loss_primal=loss_primal_part1+loss_primal_part2;
        # loss_decrease=loss_init-loss_primal;
        # loss_gap=2*loss_primal_part1+loss_primal_part2+dot(lambda_z,c_vec);
        loss_decrease = loss_init - loss_primal_best;
        loss_gap = loss_primal_best + loss_dual_best;
        iter += 1;
    end
    return (x_best, iter, lambda_best);
end

#######################
######################
#######################
function PD_image(dd::Int64, s_vec::Vector{Float64},
    D::Vector{Float64}, d::Vector{Float64}, alg::String;
    MAXITER::Int64 = 20000,
    rho_coeff::Float64 = 0.24,
    z_init::Vector{Float64} = zeros(size(B)[2]),
    lambda_init::Vector{Float64} = zeros(size(d)[1]),
    rough_norm_Bk::Float64 = 1.0,
    if_warmstart::Int64 = 1)
    ###################################################
    ###################################################

    s_vec_neg = -s_vec;
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    mu = 1.0;
    loss_init=norm(d, 1);
    nn = length(d);

    if if_warmstart == 0
        z_init = zeros(dd);
        lambda_init = zeros(nn);
    end
    # mul!(z_init, BT, lambda_init, -1, false);
    # tau_pre = 0.2;
    # sigma_pre = 200/(rough_norm_Bk^2);

    tau_pre = 1.0;
    sigma_pre = 10.0/(rough_norm_Bk^2);

    # tau_pre = 10/(rough_norm_Bk);
    # sigma_pre = 10.0/(rough_norm_Bk);

    eta = 0.5;
    gamma_pre = sigma_pre/tau_pre;

    z_current = zeros(dd); z_current .= z_init;
    z_temp = zeros(dd);
    z_erg = zeros(dd);
    z_best = zeros(dd); z_best .= z_init;


    Bz_pre = zeros(nn); 
    MultiplyByDHS!(z_current, s_vec, D, d_work_vec, Bz_pre);#mul!(Bz_pre,B,z_current);
    Bz_current = zeros(nn); Bz_current .= Bz_pre;
    Bz_middle = zeros(nn);
    Bz_temp = zeros(nn);
    Bz_erg = zeros(nn);


    lambda_temp = zeros(nn);
    lambda_current = zeros(nn); lambda_current .= lambda_init;
    lambda_erg = zeros(nn);
    lambda_best = zeros(nn); lambda_best .= lambda_init;

    BTlambda_temp = zeros(dd);
    BTlambda_current = zeros(dd); 
    MultiplyByDHST!(lambda_current, s_vec, D, n_work_vec, BTlambda_current);#mul!(BTlambda_current, BT, lambda_current);
    BTlambda_erg = zeros(dd);

    loss_decrease = 0.0;
    loss_primal_best = 1/2*norm(z_current)^2 + norm(Bz_current - d,1);
    loss_dual_best = -1/2*norm(BTlambda_current)^2 - dot(d,lambda_current);
    loss_primal_current = loss_primal_best;
    loss_dual_current = loss_dual_best;
    loss_gap_best = loss_primal_best - loss_dual_best;

    Tk = 0.0;
    iter = 0;
    while (iter < MAXITER)
        if alg == "low"
            if (loss_gap_best <= rho_coeff*loss_decrease)
                break
            end
        end

        if alg == "high"
            if (loss_gap_best <= rho_coeff/2*norm(z_best)^2)
                break
            end
        end
        primal_erg_best = 0;
        dual_erg_best = 0;
        gamma = gamma_pre * (1 + mu * tau_pre);
        tau = tau_pre * sqrt(gamma_pre/gamma)
        for counting in 0:20
            tau_temp = tau*(eta^counting);
            sigma = gamma*tau_temp;
            theta = sigma_pre/sigma;
            Bz_middle .= Bz_current .+ theta .* (Bz_current - Bz_pre);
            lambda_temp .= sigma .* (Bz_middle .- d);
            lambda_temp[lambda_temp .> 1.0] .= 1.0;
            lambda_temp[lambda_temp .< -1.0] .= -1.0;
            MultiplyByDHST!(lambda_temp, s_vec, D, n_work_vec, BTlambda_temp)
            #mul!(BTlambda_temp, BT, lambda_temp);
            z_temp .= (1/(1+tau_temp)) .* z_current .- (tau_temp/(1+tau_temp)) .* BTlambda_temp;
            MultiplyByDHS!(z_temp, s_vec, D, d_work_vec, Bz_temp)#mul!(Bz_temp, B, z_temp);
            if sqrt(sigma* tau_temp) * norm(Bz_temp - Bz_current) <=  norm(z_temp - z_current) + 3e-16
                lambda_current .= lambda_temp;
                BTlambda_current .= BTlambda_temp;
                z_current .= z_temp;
                Bz_pre .= Bz_current;
                MultiplyByDHS!(z_current, s_vec, D, d_work_vec, Bz_current)#mul!(Bz_current,B,z_current);
                tau_pre = tau_temp;
                gamma_pre = gamma;
                sigma_pre = sigma;
                loss_primal_current = 1/2*norm(z_current)^2 + norm(Bz_current - d,1);
                loss_dual_current = -1/2*norm(BTlambda_current)^2 - dot(d,lambda_current);
                break;
            end
        end
        z_erg .= Tk .* z_erg .+ sigma_pre .* z_current;
        lambda_erg .= Tk .* lambda_erg .+ sigma_pre .* lambda_current;
        Bz_erg .= Tk .* Bz_erg .+ sigma_pre .* Bz_current;
        BTlambda_erg .= Tk .* BTlambda_erg .+ sigma_pre .* BTlambda_current;
        Tk = Tk + sigma_pre;
        z_erg .= z_erg ./ Tk;
        lambda_erg .= lambda_erg ./ Tk;
        Bz_erg .= Bz_erg ./ Tk;
        BTlambda_erg .= BTlambda_erg ./ Tk;
        loss_primal_erg = 1/2*norm(z_erg)^2 + norm(Bz_erg - d,1);
        loss_dual_erg = -1/2*norm(BTlambda_erg)^2 - dot(d,lambda_erg);


        loss_gap_new = min(loss_gap_best, loss_primal_current - loss_dual_current, loss_primal_erg - loss_dual_erg);
        if loss_gap_new < loss_gap_best
            if loss_gap_new == loss_primal_current - loss_dual_current;
                z_best .= z_current;
                lambda_best .= lambda_current;
                loss_primal_best = loss_primal_current;
                loss_dual_best = loss_dual_current;
            else
                z_best .= z_erg;
                primal_erg_best = 1;
                lambda_best .= lambda_erg;
                dual_erg_best = 1;
                loss_primal_best = loss_primal_erg;
                loss_dual_best = loss_dual_erg;
            end
        end

        loss_decrease = loss_init - loss_primal_best;
        loss_gap_best = loss_primal_best - loss_dual_best;
        iter = iter + 1;
        # if mod(iter,10)==0
        #     println("iter: ",iter, ", loss decrease: ", loss_decrease, ", loss gap: ", loss_gap,
        #             ", erg best: ", primal_erg_best, dual_erg_best);
        #     println("tau: ", tau_pre, ", sigma: ", sigma_pre, ", mulre: ", tau_pre*sigma_pre*(rough_norm_Bk^2));
        # end

    end
    return (z_best, iter, lambda_best);
end



