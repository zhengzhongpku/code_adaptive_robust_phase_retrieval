include("main_file.jl")
function generated_pipeline2(arr_gen::Int64)
    iof = open("./task_arrangement/task_group_"*string(arr_gen)*".txt")
    lines = readlines(iof);
    close(iof);
    for line in lines
        decoded_curr = parse(Int64, line);
        generated_pipeline(decoded_curr);
    end
end
#generated_pipeline2(12101);
arg = parse(Int64, ARGS[1]);
result=generated_pipeline2(arg);
#include("pipeline2_1021.jl")
#041021