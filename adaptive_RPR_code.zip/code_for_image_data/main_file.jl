include("utility_functions_1021.jl")
include("data_generation_1021.jl");
include("Initializer_1021.jl");
include("IPL_solvers_0830.jl");
include("solver_two_stage_pogs_1021.jl")
include("solver_subgradient_1021.jl")
include("solver_subgradient_median_1021.jl")
path_parent="./result/"
using CPUTime
rho_admm=2.0;
rho_coeff = 0.24;
function generated_pipeline(decoded::Int64)
    log_dim=22;
    path_number=round(Int64,1e3+mod(decoded,round(Int64,1e3)));
    if ~isdir(path_parent*string(path_number)*"/")
        mkdir(path_parent*string(path_number)*"/");
    end

    decoded=round(Int64,mod(decoded,round(Int64,1e5))+1e5);
    path_target=path_parent*string(path_number)*"/"*"rna_real_data_" * string(decoded) * ".txt";
    if isfile(path_target)
        f=open(path_target,"r");
        contents=read(f,String);
        close(f);
        if occursin("Everything is completed for current trial",contents)
            return 0
        end
    end
    io=open(path_target,"w");
    #io = "";
    println(io, "decoded_value: ",decoded);
    #This integer is used for generating experiment setting

    #digit 1 (from right to left): fail_multi,0 or 1
    fail_multi=convert(Float64, mod(decoded,10));
    if (fail_multi>1)
        error("fail multi");
    end
    ################################################
    #digit 2 (from right to left): 0-8
    pfail=0.025*fld(mod(decoded,100),10);
    if (pfail>0.20001)
        error("pfail");
    end
    #################################################
    #digit 3 (from right to left): 0-1
    kk=3+3*fld(mod(decoded,round(Int64,1000)),round(Int64,100));
    if (kk>6.0001)
        error("kk");
    end
    
    #digit 4,5 (from right to left): 0-49
    num_n_vals=1+fld(mod(decoded,round(Int64,100000)),round(Int64,1000));
    if (num_n_vals>50.0001)
        error("num_n_vals");
    end
    ############################################################
    rel_tol_sel = 1e-7;
    seed = 1234;
    (b, s_vec, x)=data_generation_1021("./Data/rna-particles.png", 
            log_dim, kk, pfail, fail_multi, num_n_vals, seed);
    dd=length(x);
    nn=length(s_vec);
    println(io,"fail_multi: ",fail_multi);
    println(io,"pfail: ",pfail);
    println(io,"dd: ",dd);
    println(io,"nn: ",nn);
    println(io,"num_n_vals: ",num_n_vals);
    Wx=zeros(nn);
    work_vec = zeros(dd);
    MultiplyByHS!(x, s_vec, work_vec, Wx);
    optimized_loss=norm(Wx.^2-b,1);
    println(io,"Optimized_loss: ",optimized_loss);
    x_init = OrthogonalityInitializer(dd, s_vec, b, maxiter = 300, p_val = 0.75, use_big=false);
    println(io, "norm of x_star: ", norm(x));
    println(io, "initialization relative recovery error: ", min(norm(x_init - x) / norm(x), norm(x_init + x) / norm(x)));
    ################################################################################################
    verbose_id = 0;

    # x_est = copy(x) .+ 0.0001;
    # CPUtic();
    # (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    # "fista", "low";
    # x_true = x, maxiter_main = 10, loss_opt = optimized_loss,
    # rho_coeff = 0.24,
    # G_stepsize = 100.0,
    
    # if_diminishing = 1,
    # if_warmstart = 1,
    # if_erg = 0,

    # if_verbose = 0)
    # time_taken = CPUtoc();
    # result_output(io, "Low accuracy dual stepsize local Convergence", objs[end], optimized_loss, x_est, x, 
    # time_taken, num_steps, outer_iters);
    # if objs[end] - optimized_loss < -(1e-4)
    #     println(io, "There is sufficient evidence that the sharpness condition does not hold.")
    #     println(io, "Everything is completed for current trial")
    #     close(io)
    #     return 0;
    # end
    # #################################################################################
    #######################################Two Stage PL###################################
    rel_thresh = 1e-7;
    # CPUtic();
    # x_est = copy(x_init);
    # num_steps = 0;
    # #tol=1e-3,maxiter=20
    # (x_est, objs, total_cg_calcs1, num_steps1, outer_iters1) = ProxLinearQuadratic(x_est,s_vec,b,maxiter=10,
    #         tol=1e-4,eps_qp=1e-4);
    # println(io, "First Stage Outer iterations: ", outer_iters1);
    # println(io, "First Stage subproblem iterations: ", num_steps1);
    # println(io, "First Stage CG iterations: ", total_cg_calcs1);
    # (x_est, objs, total_cg_calcs2, num_steps2, outer_iters2) = ProxLinearQuadratic(x_est,s_vec,b,maxiter=5,
    #         tol=1e-4,eps_qp=1e-7);
    # loss_thresh=objs[end];
    # println(io, "Second Stage Outer iterations: ", outer_iters2);
    # println(io, "Second Stage subproblem iterations: ", num_steps2);
    # println(io, "Second Stage CG iterations: ", total_cg_calcs2);
    
    # time_taken = CPUtoc();
    # result_output(io, "Two Stage PL", objs[end], optimized_loss, x_est, x, 
    # time_taken, num_steps1 + num_steps2, outer_iters1+ outer_iters2);
    ################################subgradient#####################################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, x_true = x, 
                            q = 0.998);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Convergence 998", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, num_steps);

    
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, x_true = x, 
                            q = 0.997);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Convergence 997", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, num_steps);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, x_true = x, 
                            q = 0.993);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Convergence 993", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, num_steps);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, x_true = x, 
                            q = 0.989);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Convergence 989", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, num_steps);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, x_true = x, 
                            q = 0.983);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Convergence 983", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, num_steps);
    ############################## IPL-low ##############################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "low";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 100.0,
    if_diminishing = 0,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "Low accuracy dual Convergence", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);
    ############################## IPL-high ##############################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "high";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 100.0,
    if_diminishing = 0,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "High accuracy dual Convergence", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);

    ############################## IPLD-fista-low ##############################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "low";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 1000.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "Low accuracy dual stepsize Convergence 1000", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);
    
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "low";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 100.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "Low accuracy dual stepsize Convergence 100", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "low";
    x_true = x, maxiter_main = 2000, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 10.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "Low accuracy dual stepsize Convergence 10", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);


    ############################## IPLD-fista-high ##############################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "high";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 1000.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "High accuracy dual stepsize Convergence 1000", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "high";
    x_true = x, maxiter_main = 200, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 100.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "High accuracy dual stepsize Convergence 100", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=IPL_solvers_image(x_est, s_vec, b, 
    "fista", "high";
    x_true = x, maxiter_main = 2000, loss_opt = optimized_loss, rel_error_tol = rel_thresh,
    rho_coeff = 0.24,
    G_stepsize = 10.0,
    if_diminishing = 1,
    if_warmstart = 1,
    if_erg = 0,
    if_verbose = 0)
    time_taken = CPUtoc();
    result_output(io, "High accuracy dual stepsize Convergence 10", objs[end], optimized_loss, x_est, x, 
    time_taken, num_steps, outer_iters);

    ##############################################################################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient_median(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, 
        x_true = x, g_multiplier = 0.5);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Median Convergence 05", objs[end], optimized_loss, x_est, x, 
        time_taken, num_steps, num_steps);

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient_median(s_vec, b, x_est, rel_tol = rel_thresh, maxiter = 10000, 
        x_true = x, g_multiplier = 0.1);
    time_taken = CPUtoc();
    result_output(io, "Subgradient Algorithm Median Convergence 01", objs[end], optimized_loss, x_est, x, 
        time_taken, num_steps, num_steps);

    println(io, "Everything is completed for current trial.")
    close(io);
end
# fail_multi_index = 1;
# p_fail_index = 4;
# kk_index = 1;
# rep_index = 0;
# code_num = fail_multi_index + p_fail_index*10 + kk_index*100 + rep_index*1000 + 100000;
# generated_pipeline(100141);