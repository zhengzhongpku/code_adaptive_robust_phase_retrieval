using Random
using Statistics
using LinearAlgebra
using DelimitedFiles
using Arpack
using StatsBase
using PyPlot
include("Hadamard.jl")
function MultiplyByHS!(x::Vector{Float64},
                        s_vec::Vector{Float64},
                        d_work_vec::Vector{Float64},
                        result::Vector{Float64})
    result[:] .= 0;
    dd = length(x);# 变量维数
    nn = length(s_vec);# 样本个数
    kk = round(Int64, nn / dd);
    @inbounds for ll = 1:kk
        ind_start = (ll - 1) * dd;
    # d_work_vec[:] = s_vec[indset] .* x;
        for jj = 1:dd
            d_work_vec[jj] = s_vec[ind_start + jj] * x[jj];
        end
        Hadamard.hadmult!(d_work_vec);# unscaled version
    # result[indset] += D[indset] .* d_work_vec;
        for jj = 1:dd
            result[ind_start + jj] += d_work_vec[jj];
        end
    end
    @inbounds for jj = 1:nn
        result[jj] /= sqrt(dd);
    end
end

function MultiplyByDHS!(x::Vector{Float64},
                        s_vec::Vector{Float64},
                        D::Vector{Float64},
                        d_work_vec::Vector{Float64},
                        result::Vector{Float64})
    result[:] .= 0;
    dd = length(x);# 变量维数
    nn = length(s_vec);# 样本个数
    kk = round(Int64, nn / dd);
    @inbounds for ll = 1:kk
        ind_start = (ll - 1) * dd;
    # d_work_vec[:] = s_vec[indset] .* x;
        for jj = 1:dd
            d_work_vec[jj] = s_vec[ind_start + jj] * x[jj];
        end
        Hadamard.hadmult!(d_work_vec);# unscaled version
    # result[indset] += D[indset] .* d_work_vec;
        for jj = 1:dd
            result[ind_start + jj] += D[ind_start + jj] * d_work_vec[jj];
        end
    end
    @inbounds for jj = 1:nn
        result[jj] /= sqrt(dd);
    end
end

# MultiplyByDHST!(v, s, D, n_work_vec, result)
#
# Sets result = S' * H * diagm(D) * v, where H and S are defined as in
# the header to this file. The vector n_work_vec is a size n vector,
# where v is of size n as well. result is of size d.
function MultiplyByDHST!(v::Vector{Float64},
                         s_vec::Vector{Float64},
                         D::Vector{Float64},
                         n_work_vec::Vector{Float64},
                         result::Vector{Float64})
    dd = length(result);
    result[:] .= 0;
    n_work_vec[:] .= 0;
    nn = length(v);
    kk = round(Int64, nn / dd);
  # n_work_vec[:] = D .* v;
    @inbounds for jj = 1:nn
        n_work_vec[jj] = D[jj] * v[jj];
    end
    @inbounds for ll = 1:kk
        ind_start = (ll - 1) * dd;
        ind_end = ind_start + dd;
        indset = ((ll - 1) * dd + 1):(ll * dd);
        Hadamard.hadmult!(view(n_work_vec, indset));
    # result[:] += s_vec[indset] .* n_work_vec[indset];
        for jj = 1:dd
            result[jj] += s_vec[ind_start + jj] * n_work_vec[ind_start + jj];
        end
    end
    @inbounds for jj = 1:dd
        result[jj] /= sqrt(dd);
    end
end

# (x, iter) = InvertHadamardSystem(d, s, rho, D, b; x0, eps_cg, residuals)
#
# Sets x to be the solution to the (positive definite) linear equation
#
# (alpha * I + rho * S' * H * D * H * S) * x = b
#
# where I is the d-by-d identity, D is the corresponding diagonal
# matrix to the vector D, and S is the matrix
#
# S' = [S1 S2 ... Sk]
#
# of diagonal matrices Si. The Si are d-by-d diagonal matrices, where
# the i-th such matrix has diagonal entries given by the i-th block of
# entries of the vector s. We scale s to have entries +/-1 / sqrt(k).
#
# The CG method is solved to relative tolerance eps_cg (default 10^(-6)).
# Also returns the number of iterations of CG.
function InvertHadamardSystem(dd::Int64,
        s_vec::Vector{Float64},
        rho::Float64,
        D::Vector{Float64},
        b::Vector{Float64};
        x_init::Vector{Float64} = zeros(0),
        eps_cg::Float64 = 1e-6,
        residuals::Vector{Float64} = Float64[],
        alpha::Float64 = 1.0)
    nn = length(s_vec);
    kk = convert(Int64, nn / dd);
    # s_vec = sign(s_vec) / sqrt(kk);
    maxiter = dd;
    A_p_vec = zeros(dd);
    d_work_vec = zeros(dd);
    x = zeros(dd);
    if (!isempty(x_init))
        x[:]  = x_init[:];
    end
    # Check sizes:
    if (nn != length(s_vec) || nn != length(D) || dd != length(b))
        error("Bad vector sizes.");
    end
    MultiplyByIplusHDH!(x, dd, kk, rho, s_vec, D, d_work_vec, A_p_vec, alpha);
    # NOTE: Replaced with @inbounds for faster looping and construction
    # resid = b - A_p_vec;
    resid = zeros(dd);
    @inbounds for jj = 1:dd
        resid[jj] = b[jj] - A_p_vec[jj];
    end
    p_vec = copy(resid);
    resid_square = dot(resid, resid);
    norm_b_squared = dot(b, b);
    iter = 0;
    while (resid_square / norm_b_squared > eps_cg^2 && iter <= maxiter)
        iter = iter + 1;
        MultiplyByIplusHDH!(p_vec, dd, kk, rho, s_vec, D,
        d_work_vec, A_p_vec, alpha);
        stepsize = resid_square / dot(p_vec, A_p_vec);
        # Replaced additions with for loops for speed
        for jj = 1:dd
            x[jj] += stepsize * p_vec[jj];
            resid[jj] -= stepsize * A_p_vec[jj];
        end
        new_resid_square = dot(resid, resid);
        if (!isempty(residuals))
            residuals[iter] = new_resid_square;
        end
        # p_vec = resid + (new_resid_square / resid_square) * p_vec;
        @inbounds for jj = 1:dd
            p_vec[jj] = resid[jj] + (new_resid_square / resid_square) * p_vec[jj];
        end
        resid_square = new_resid_square;
        #println("CG Problem Iteration ", iter, ", Residual Norm2: ", resid_square);
    end
    return (x, iter);
end

# MultiplyByIplusHDinvH!(x, d, k, rho, s_vec, D, d_work_vec, result)
#
# Sets result to be equal to
#
# W' * (I + rho * D)^{-1} * W * x
#
# where W = H * S, as in the description of InvertHadamardSystem.
function MultiplyByIplusHDinvH!(x::Vector{Float64},
            dd::Int64,
            kk::Int64,
            rho::Float64,
            s_vec::Vector{Float64},
            D::Vector{Float64},
            d_work_vec::Vector{Float64},
            result::Vector{Float64})
    result[:] = 0;
    @inbounds for ll = 1:kk
        indset = ((ll - 1) * dd + 1):(ll * dd);
        d_work_vec[:] = s_vec[indset] .* x;
        Hadamard.hadmult!(d_work_vec);
        d_work_vec ./= (1 + rho * D[indset]);
        Hadamard.hadmult!(d_work_vec);
        d_work_vec /= dd;
        result[:] += s_vec[indset] .* d_work_vec;
    end
end

#(alpha * I + rho * S' * H * D * H * S) * x
function MultiplyByIplusHDH!(x::Vector{Float64},
        dd::Int64,
        kk::Int64,
        rho::Float64,
        s_vec::Vector{Float64},
        D::Vector{Float64},
        d_work_vec::Vector{Float64},
        result::Vector{Float64},
        alpha::Float64 = 1.0)
    result[:] .= 0;
    @inbounds for ll = 1:kk
        init_ind = (ll - 1) * dd;
        # indset = (init_ind + 1):(init_ind + dd)
        # d_work_vec[:] = s_vec[indset] .* x;
        for jj = 1:dd
            d_work_vec[jj] = s_vec[init_ind + jj] * x[jj];
        end
        Hadamard.hadmult!(d_work_vec);
        # d_work_vec .*= D[indset];
        for jj = 1:dd
            d_work_vec[jj] *= D[init_ind + jj];
        end
        Hadamard.hadmult!(d_work_vec);
        d_work_vec /= dd;
        # result[:] += rho * s_vec[indset] .* d_work_vec;
        for jj = 1:dd
            result[jj] += rho * s_vec[init_ind + jj] * d_work_vec[jj];
        end
    end
    result[:] += alpha * x;
end

function result_output(io, alg_name, final_loss, opt_loss, x_est, x_true, time_taken, subprob_iters, outer_iters)
    rel_error = min(norm(x_est - x_true) / norm(x_true), norm(x_est + x_true) / norm(x_true));
    println(io, "#################################################################################")
    println(io, alg_name, " Completed.");
    println(io, alg_name, " Final loss: ", final_loss);
    println(io, alg_name, " Loss Gap: ", final_loss - opt_loss);
    println(io, alg_name, " relative recovery error: ", rel_error);
    println(io, alg_name, " Time consumption: ", time_taken);
    println(io, alg_name, " subproblem iterations: ", subprob_iters);
    println(io, alg_name, " Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x_true)/norm(x_true)^2)*x_true;
    orth_part=x_est-proj_part;
    println(io, alg_name, " projection norm: ", norm(proj_part));
    println(io, alg_name, " orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
end