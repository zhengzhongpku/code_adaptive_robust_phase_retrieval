import os
import random
import math
path0 = "./result/"
def judge_complete(path):
    if not os.path.isfile(path):
        return 0
    f=open(path)
    contents = f.read()
    f.close()
    if "Everything is completed for current trial" in contents:
        return 1
    return 0
def dispose_str_list(str_list):
    str_list0=str_list.copy()
    if len(str_list0) <= 1:
        return str_list0
    for i in range(len(str_list0)-1):
        str_list0[i]=str_list0[i]+"\n"
    return str_list0
core_usable = 10
failmulti_collection=["1"]
pfail_collection=["4"]
kk_collection=["1"]
n_vals_collection=[]
for i in range(0,1):
    for j in range(0,10):
        n_vals_collection.append(str(i)+str(j))

complete_task_collection=[]
incomplete_task_collection=[]
for failmulti in failmulti_collection:
    for pfail in pfail_collection:
            for kk in kk_collection:
                for n_vals in n_vals_collection:
                    decoded_id0="1"+n_vals+kk+pfail+failmulti
                    mother_path="1"+kk+pfail+failmulti
                    file_path="rna_real_data_1"+n_vals+kk+pfail+failmulti+".txt"
                    path_complete=path0+mother_path+"/"+file_path
                    judge=False
                    judge=judge_complete(path_complete)
                    if judge:
                        complete_task_collection.append(decoded_id0)
                    else:
                        incomplete_task_collection.append(decoded_id0)
num_total=len(failmulti_collection)*len(pfail_collection)*len(kk_collection)*len(n_vals_collection)
print("Num total: "+str(num_total))
print("Num of completed task: "+str(len(complete_task_collection)))
print("Num of incompleted task: "+str(len(incomplete_task_collection)))
if len(incomplete_task_collection) == 0:
    print("Everything is completed.")
    quit()
num_incomp=len(incomplete_task_collection)
for i in range(core_usable):
    f = open("./task_arrangement/task_group_"+str(i)+".txt","w")
    f.close()
if num_incomp <= core_usable:
    print("One core one task with core num: "+str(len(incomplete_task_collection)))
    print(incomplete_task_collection)
    for i in range(num_incomp):
        f = open("./task_arrangement/task_group_"+str(i)+".txt","w")
        f.write(incomplete_task_collection[i])
        f.close()
random.seed(1234)
if num_incomp > core_usable:
    print("We do use core num: ", core_usable)
    shuff_collection = random.sample(incomplete_task_collection, k=num_incomp)
    ratio = math.ceil(num_incomp/core_usable)
    for i in range(core_usable-1):
        f = open("./task_arrangement/task_group_"+str(i)+".txt","w")
        f.writelines(dispose_str_list(shuff_collection[(i*(ratio)):((i+1)*ratio)]))
        f.close()
    i=core_usable-1
    f = open("./task_arrangement/task_group_"+str(i)+".txt","w")
    f.writelines(dispose_str_list(shuff_collection[(i*(ratio)):num_incomp]))
    f.close()
print("Task generating completed")
